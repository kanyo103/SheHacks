# Overview

This is a Flask-based loyalty rewards web application for Mukuru customers that allows them to earn, manage, and redeem loyalty points through remittance transactions. The system features a complete end-to-end experience including money sending functionality, points management, rewards marketplace, and transaction history tracking. The application uses an in-memory data store for prototyping purposes and includes engaging visual elements like animations and modern UI components to create an intuitive user experience.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Template Engine**: Flask Jinja2 templating with responsive HTML templates
- **CSS Framework**: Bootstrap 5 for responsive design and component styling
- **Custom Styling**: CSS variables for brand theming with Mukuru color scheme
- **JavaScript Architecture**: Vanilla JavaScript with class-based organization for animations and UI interactions
- **Animation System**: Custom animation library with intersection observers and particle effects

## Backend Architecture
- **Web Framework**: Flask with CORS enabled for API endpoints
- **Session Management**: Flask sessions for customer authentication and state management
- **Routing**: Blueprint-style route organization in separate routes.py file
- **Logging**: Python logging module configured for debugging

## Data Storage
- **Data Layer**: In-memory data store using Python classes and dictionaries
- **Models**: Simple data models for customers, transactions, rewards, and redemptions
- **Sample Data**: Pre-populated with sample customers and rewards catalog
- **Data Persistence**: No persistent storage - data resets on application restart

## Business Logic
- **Points System**: 1 point earned per R100 sent in remittance transactions
- **Tier System**: Bronze/Silver/Gold customer tiers based on points earned
- **Rewards Catalog**: Categorized rewards (Airtime, Grocery, Fuel, Entertainment, Shopping, Travel)
- **Transaction Processing**: Simulated money sending with automatic points calculation

## Security & Authentication
- **Session-based Authentication**: Customer selection stores ID in Flask session
- **Environment Configuration**: Secret key configuration via environment variables
- **CORS**: Cross-origin resource sharing enabled for API endpoints

# External Dependencies

## Frontend Libraries
- **Bootstrap 5**: CSS framework for responsive design and components
- **Font Awesome 6**: Icon library for UI elements and visual indicators
- **Animate.css**: CSS animation library for enhanced user experience

## Backend Dependencies
- **Flask**: Python web framework for application server
- **Flask-CORS**: Cross-origin resource sharing extension
- **Python Standard Library**: datetime, uuid, os, logging modules

## Development Tools
- **Debug Mode**: Flask development server with hot reload
- **Logging**: Debug-level logging for development and troubleshooting

## Hosting & Deployment
- **Server Configuration**: Flask development server on host 0.0.0.0 port 5000
- **Static Assets**: CSS and JavaScript files served via Flask static file handling
- **Template Rendering**: Server-side template rendering with Jinja2

Note: The application currently uses in-memory storage which makes it suitable for demonstration and prototyping. For production deployment, a persistent database solution would need to be integrated.